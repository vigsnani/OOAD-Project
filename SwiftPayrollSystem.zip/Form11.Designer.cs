﻿namespace SwiftPayRoll
{
    partial class Form11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.City = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.Label();
            this.Return = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.CityTB = new System.Windows.Forms.TextBox();
            this.PhoneTB = new System.Windows.Forms.TextBox();
            this.eMailTB = new System.Windows.Forms.TextBox();
            this.eMail = new System.Windows.Forms.Label();
            this.JobDesignation = new System.Windows.Forms.Label();
            this.Zip = new System.Windows.Forms.Label();
            this.ZipTB = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.StateTB = new System.Windows.Forms.TextBox();
            this.AddLine2 = new System.Windows.Forms.Label();
            this.AddLine2TB = new System.Windows.Forms.TextBox();
            this.AddLine1 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.DOB = new System.Windows.Forms.Label();
            this.DOBTB = new System.Windows.Forms.TextBox();
            this.GenderTB = new System.Windows.Forms.TextBox();
            this.Gender = new System.Windows.Forms.Label();
            this.LName = new System.Windows.Forms.Label();
            this.FName = new System.Windows.Forms.Label();
            this.LNameTB = new System.Windows.Forms.TextBox();
            this.FNameTB = new System.Windows.Forms.TextBox();
            this.AddLine1TB = new System.Windows.Forms.TextBox();
            this.IDTB = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ID = new System.Windows.Forms.Label();
            this.JobID = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // City
            // 
            this.City.AutoSize = true;
            this.City.Location = new System.Drawing.Point(155, 385);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(36, 13);
            this.City.TabIndex = 56;
            this.City.Text = "City   :";
            // 
            // Phone
            // 
            this.Phone.AutoSize = true;
            this.Phone.Location = new System.Drawing.Point(141, 355);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(50, 13);
            this.Phone.TabIndex = 55;
            this.Phone.Text = "Phone   :";
            // 
            // Return
            // 
            this.Return.Location = new System.Drawing.Point(432, 433);
            this.Return.Name = "Return";
            this.Return.Size = new System.Drawing.Size(75, 23);
            this.Return.TabIndex = 54;
            this.Return.Text = "Return";
            this.Return.UseVisualStyleBackColor = true;
            this.Return.Click += new System.EventHandler(this.Return_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(239, 433);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 53;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // CityTB
            // 
            this.CityTB.Location = new System.Drawing.Point(197, 383);
            this.CityTB.Name = "CityTB";
            this.CityTB.Size = new System.Drawing.Size(100, 20);
            this.CityTB.TabIndex = 50;
            // 
            // PhoneTB
            // 
            this.PhoneTB.Location = new System.Drawing.Point(197, 352);
            this.PhoneTB.Name = "PhoneTB";
            this.PhoneTB.Size = new System.Drawing.Size(100, 20);
            this.PhoneTB.TabIndex = 51;
            // 
            // eMailTB
            // 
            this.eMailTB.Location = new System.Drawing.Point(197, 320);
            this.eMailTB.Name = "eMailTB";
            this.eMailTB.Size = new System.Drawing.Size(100, 20);
            this.eMailTB.TabIndex = 52;
            // 
            // eMail
            // 
            this.eMail.AutoSize = true;
            this.eMail.Location = new System.Drawing.Point(147, 323);
            this.eMail.Name = "eMail";
            this.eMail.Size = new System.Drawing.Size(44, 13);
            this.eMail.TabIndex = 49;
            this.eMail.Text = "eMail   :";
            // 
            // JobDesignation
            // 
            this.JobDesignation.AutoSize = true;
            this.JobDesignation.Location = new System.Drawing.Point(99, 291);
            this.JobDesignation.Name = "JobDesignation";
            this.JobDesignation.Size = new System.Drawing.Size(92, 13);
            this.JobDesignation.TabIndex = 48;
            this.JobDesignation.Text = "Job Designation  :";
            // 
            // Zip
            // 
            this.Zip.AutoSize = true;
            this.Zip.Location = new System.Drawing.Point(423, 258);
            this.Zip.Name = "Zip";
            this.Zip.Size = new System.Drawing.Size(34, 13);
            this.Zip.TabIndex = 46;
            this.Zip.Text = "Zip   :";
            // 
            // ZipTB
            // 
            this.ZipTB.Location = new System.Drawing.Point(479, 255);
            this.ZipTB.Name = "ZipTB";
            this.ZipTB.Size = new System.Drawing.Size(100, 20);
            this.ZipTB.TabIndex = 45;
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(413, 226);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(44, 13);
            this.State.TabIndex = 44;
            this.State.Text = "State   :";
            // 
            // StateTB
            // 
            this.StateTB.Location = new System.Drawing.Point(479, 223);
            this.StateTB.Name = "StateTB";
            this.StateTB.Size = new System.Drawing.Size(100, 20);
            this.StateTB.TabIndex = 43;
            // 
            // AddLine2
            // 
            this.AddLine2.AutoSize = true;
            this.AddLine2.Location = new System.Drawing.Point(409, 194);
            this.AddLine2.Name = "AddLine2";
            this.AddLine2.Size = new System.Drawing.Size(48, 13);
            this.AddLine2.TabIndex = 42;
            this.AddLine2.Text = "Line 2   :";
            // 
            // AddLine2TB
            // 
            this.AddLine2TB.Location = new System.Drawing.Point(479, 191);
            this.AddLine2TB.Name = "AddLine2TB";
            this.AddLine2TB.Size = new System.Drawing.Size(100, 20);
            this.AddLine2TB.TabIndex = 41;
            // 
            // AddLine1
            // 
            this.AddLine1.AutoSize = true;
            this.AddLine1.Location = new System.Drawing.Point(409, 162);
            this.AddLine1.Name = "AddLine1";
            this.AddLine1.Size = new System.Drawing.Size(48, 13);
            this.AddLine1.TabIndex = 40;
            this.AddLine1.Text = "Line 1   :";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(461, 127);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(45, 13);
            this.Address.TabIndex = 39;
            this.Address.Text = "Address";
            // 
            // DOB
            // 
            this.DOB.AutoSize = true;
            this.DOB.Location = new System.Drawing.Point(149, 258);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(42, 13);
            this.DOB.TabIndex = 38;
            this.DOB.Text = "DOB   :";
            // 
            // DOBTB
            // 
            this.DOBTB.Location = new System.Drawing.Point(197, 255);
            this.DOBTB.Name = "DOBTB";
            this.DOBTB.Size = new System.Drawing.Size(100, 20);
            this.DOBTB.TabIndex = 36;
            // 
            // GenderTB
            // 
            this.GenderTB.Location = new System.Drawing.Point(197, 223);
            this.GenderTB.Name = "GenderTB";
            this.GenderTB.Size = new System.Drawing.Size(100, 20);
            this.GenderTB.TabIndex = 37;
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Location = new System.Drawing.Point(137, 226);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(54, 13);
            this.Gender.TabIndex = 35;
            this.Gender.Text = "Gender   :";
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Location = new System.Drawing.Point(121, 194);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(70, 13);
            this.LName.TabIndex = 34;
            this.LName.Text = "Last Name   :";
            // 
            // FName
            // 
            this.FName.AutoSize = true;
            this.FName.Location = new System.Drawing.Point(122, 162);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(69, 13);
            this.FName.TabIndex = 33;
            this.FName.Text = "First Name   :";
            // 
            // LNameTB
            // 
            this.LNameTB.Location = new System.Drawing.Point(197, 191);
            this.LNameTB.Name = "LNameTB";
            this.LNameTB.Size = new System.Drawing.Size(100, 20);
            this.LNameTB.TabIndex = 29;
            // 
            // FNameTB
            // 
            this.FNameTB.Location = new System.Drawing.Point(197, 159);
            this.FNameTB.Name = "FNameTB";
            this.FNameTB.Size = new System.Drawing.Size(100, 20);
            this.FNameTB.TabIndex = 28;
            // 
            // AddLine1TB
            // 
            this.AddLine1TB.Location = new System.Drawing.Point(479, 159);
            this.AddLine1TB.Name = "AddLine1TB";
            this.AddLine1TB.Size = new System.Drawing.Size(100, 20);
            this.AddLine1TB.TabIndex = 30;
            //this.AddLine1TB.TextChanged += new System.EventHandler(this.AddLine1TB_TextChanged);
            // 
            // IDTB
            // 
            this.IDTB.Location = new System.Drawing.Point(197, 127);
            this.IDTB.Name = "IDTB";
            this.IDTB.Size = new System.Drawing.Size(100, 20);
            this.IDTB.TabIndex = 31;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SwiftPayRoll.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(14, 39);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(112, 130);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(79, 13);
            this.ID.TabIndex = 26;
            this.ID.Text = "Employee ID   :";
            // 
            // JobID
            // 
            this.JobID.FormattingEnabled = true;
            this.JobID.Location = new System.Drawing.Point(197, 288);
            this.JobID.Name = "JobID";
            this.JobID.Size = new System.Drawing.Size(48, 21);
            this.JobID.TabIndex = 57;
            // 
            // Form11
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 495);
            this.Controls.Add(this.JobID);
            this.Controls.Add(this.City);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.Return);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.CityTB);
            this.Controls.Add(this.PhoneTB);
            this.Controls.Add(this.eMailTB);
            this.Controls.Add(this.eMail);
            this.Controls.Add(this.JobDesignation);
            this.Controls.Add(this.Zip);
            this.Controls.Add(this.ZipTB);
            this.Controls.Add(this.State);
            this.Controls.Add(this.StateTB);
            this.Controls.Add(this.AddLine2);
            this.Controls.Add(this.AddLine2TB);
            this.Controls.Add(this.AddLine1);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.DOBTB);
            this.Controls.Add(this.GenderTB);
            this.Controls.Add(this.Gender);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.FName);
            this.Controls.Add(this.LNameTB);
            this.Controls.Add(this.FNameTB);
            this.Controls.Add(this.AddLine1TB);
            this.Controls.Add(this.IDTB);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ID);
            this.Name = "Form11";
            this.Text = "Form11";
            this.Load += new System.EventHandler(this.Form11_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label City;
        private System.Windows.Forms.Label Phone;
        private System.Windows.Forms.Button Return;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox CityTB;
        private System.Windows.Forms.TextBox PhoneTB;
        private System.Windows.Forms.TextBox eMailTB;
        private System.Windows.Forms.Label eMail;
        private System.Windows.Forms.Label JobDesignation;
        private System.Windows.Forms.Label Zip;
        private System.Windows.Forms.TextBox ZipTB;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.TextBox StateTB;
        private System.Windows.Forms.Label AddLine2;
        private System.Windows.Forms.TextBox AddLine2TB;
        private System.Windows.Forms.Label AddLine1;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label DOB;
        private System.Windows.Forms.TextBox DOBTB;
        private System.Windows.Forms.TextBox GenderTB;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.Label FName;
        private System.Windows.Forms.TextBox LNameTB;
        private System.Windows.Forms.TextBox FNameTB;
        private System.Windows.Forms.TextBox AddLine1TB;
        private System.Windows.Forms.TextBox IDTB;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.ComboBox JobID;

    }
}